"""
Print a formatted qualitative example for the report's Section 7.

Picks a user with a rich training history, generates a top-10 BPR
recommendation, and produces a counterfactual explanation via the
existing explainer. Output is formatted as LaTeX-ready text that can
be pasted directly into the qualitative-example table.

Usage on Amarel (from project root, cs550 env active):
    python scripts/qualitative_example.py --user 42

Or let it auto-pick a user with a good story:
    python scripts/qualitative_example.py
"""
from __future__ import annotations

import argparse
import pickle
import sys
from pathlib import Path

import numpy as np
import torch

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from models.hybrid_ncf import HybridNCF
from explain.counterfactual import CounterfactualExplainer
from explain.recommend import Recommender


def pick_interesting_user(data, min_train=50, seed=13):
    """Find a user with plenty of ratings so the explanation has depth."""
    from collections import Counter
    counts = Counter()
    for row in data["train"]:
        counts[int(row[0])] += 1
    # Sort by rating count descending; pick a user with rich but not maximal history
    sorted_users = sorted(counts.items(), key=lambda x: -x[1])
    # Take a user from the 30-50th percentile -- has good history, not an outlier
    mid = len(sorted_users) // 3
    rng = np.random.RandomState(seed)
    idx = mid + rng.randint(0, 50)
    return sorted_users[idx][0]


def load_model(ckpt_path, data, device):
    ckpt = torch.load(ckpt_path, map_location=device, weights_only=False)
    ckpt_args = ckpt.get("args", {})
    model = HybridNCF(
        n_users=data["n_users"],
        n_movies=data["n_movies"],
        n_genres=data["n_genres"],
        gmf_dim=ckpt_args.get("gmf_dim", 32),
        mlp_dim=ckpt_args.get("mlp_dim", 32),
        dropout=ckpt_args.get("dropout", 0.2),
    ).to(device)
    model.load_state_dict(ckpt["model_state_dict"])
    model.eval()
    return model


def tex_escape(s: str) -> str:
    """Minimal LaTeX escaping for movie titles (apostrophes, ampersands, etc.)."""
    return (
        s.replace("&", r"\&")
         .replace("_", r"\_")
         .replace("#", r"\#")
         .replace("$", r"\$")
         .replace("%", r"\%")
    )


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="data/processed.pkl")
    ap.add_argument("--ckpt", default="checkpoints/hybrid_ncf_bpr.pt",
                    help="Which model to use for the example (BPR recommended for ranking quality)")
    ap.add_argument("--user", type=int, default=None,
                    help="User index. If omitted, auto-pick an interesting user.")
    args = ap.parse_args()

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    with open(args.data, "rb") as f:
        data = pickle.load(f)

    model = load_model(args.ckpt, data, device)
    recommender = Recommender(model, data, device)
    explainer = CounterfactualExplainer(model, data, device)

    user_idx = args.user
    if user_idx is None:
        user_idx = pick_interesting_user(data)
        print(f"# Auto-selected user {user_idx}", file=sys.stderr)

    # Top-10 recommendations
    recs = recommender.recommend(user_idx=user_idx, k=10)
    target = recs[0]  # use the top pick for the example

    exp = explainer.explain(
        user_idx=user_idx,
        target_movie_idx=target.movie_idx,
        n_causes=3,
        n_alternatives=3,
    )

    # ============================================================
    # Print human-readable summary
    # ============================================================
    print("=" * 72)
    print("QUALITATIVE EXAMPLE (human-readable)")
    print("=" * 72)
    print(f"User:             {user_idx}")
    print(f"Top recommendation:  {target.title}")
    print(f"Predicted score:  {exp.predicted_score:.4f}")
    print()
    print("Top causes (removing these would most reduce the predicted score):")
    for c in exp.cause_items:
        print(f"  * {c.title:40s}  user rating={c.user_rating:.1f}  Δ={c.delta_score:+.4f}")
    print()
    print("Alternative recommendations (if causes ablated):")
    for a in exp.alternatives:
        print(f"  * {a.title:40s}  new score={a.new_score:.4f}")
    print()
    print("Top genre attributions:")
    for g, w in exp.top_genres:
        print(f"  * {g:20s}  weight={w*100:.1f}%")

    # ============================================================
    # Print LaTeX-ready table body (ready to paste into report Section 7)
    # ============================================================
    print()
    print("=" * 72)
    print("LATEX TABLE BODY (paste into the `tab:expl` table in report.tex)")
    print("=" * 72)
    print()
    tex = []
    tex.append(r"\textbf{Causes} & " + tex_escape(exp.cause_items[0].title)
               + f" & $\\Delta={exp.cause_items[0].delta_score:+.4f}$ \\\\")
    for c in exp.cause_items[1:3]:
        tex.append(r"                & " + tex_escape(c.title)
                   + f" & $\\Delta={c.delta_score:+.4f}$ \\\\")
    tex.append(r"\midrule")
    tex.append(r"\textbf{Alternatives} & " + tex_escape(exp.alternatives[0].title)
               + f" & score={exp.alternatives[0].new_score:.3f} \\\\")
    for a in exp.alternatives[1:3]:
        tex.append(r"                      & " + tex_escape(a.title)
                   + f" & score={a.new_score:.3f} \\\\")
    tex.append(r"\midrule")
    if exp.top_genres:
        g, w = exp.top_genres[0]
        tex.append(r"\textbf{Genres}       & " + g + f" & {w*100:.1f}\\% \\\\")
        for g, w in exp.top_genres[1:]:
            tex.append(r"                      & " + g + f" & {w*100:.1f}\\% \\\\")
    print("\n".join(tex))

    # ============================================================
    # Also print the substitutions for the narrative text
    # ============================================================
    print()
    print("=" * 72)
    print("TEXT SUBSTITUTIONS for the paragraph right above the table")
    print("=" * 72)
    print(f"  [UID]          ->  {user_idx}")
    print(f"  [MOVIE-TITLE]  ->  {target.title}")


if __name__ == "__main__":
    main()
