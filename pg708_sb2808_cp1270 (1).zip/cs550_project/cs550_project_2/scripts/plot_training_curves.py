"""
Generate a two-panel training-curve figure for the report.

Panel A: MSE variant -- train / val RMSE over epochs
Panel B: BPR variant -- BPR loss (left axis) and sampled NDCG@10 (right axis)

Usage:
    python scripts/plot_training_curves.py
    # -> writes report/figures/training_curves.pdf and .png
"""
import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mse_csv", default="results/training_curve.csv")
    ap.add_argument("--bpr_csv", default="results/training_curve_bpr.csv")
    ap.add_argument("--out_pdf", default="report/figures/training_curves.pdf")
    ap.add_argument("--out_png", default="report/figures/training_curves.png")
    args = ap.parse_args()

    mse = pd.read_csv(args.mse_csv)
    bpr = pd.read_csv(args.bpr_csv)

    # ---- Figure setup ----
    plt.rcParams.update({
        "font.family": "serif",
        "font.size":    9,
        "axes.spines.top":   False,
        "axes.spines.right": False,
        "axes.grid":  True,
        "grid.alpha": 0.3,
    })
    fig, axes = plt.subplots(1, 2, figsize=(7.0, 2.6))

    # ---- Panel A: MSE variant ----
    ax = axes[0]
    ax.plot(mse["epoch"], mse["train_rmse"], marker="o", markersize=3,
            color="#1E2761", label="Train RMSE")
    ax.plot(mse["epoch"], mse["val_rmse"], marker="s", markersize=3,
            color="#F25C54", label="Val RMSE")
    ax.set_xlabel("Epoch")
    ax.set_ylabel("RMSE")
    ax.set_title("(a) MSE variant", fontsize=10, loc="left", fontweight="bold")
    ax.legend(loc="upper right", frameon=False, fontsize=8)
    ax.set_xticks(mse["epoch"].astype(int))

    # ---- Panel B: BPR variant ----
    ax = axes[1]
    ax2 = ax.twinx()
    ax2.spines["top"].set_visible(False)

    ln1 = ax.plot(bpr["epoch"], bpr["train_bpr_loss"], marker="o",
                  markersize=3, color="#1E2761", label="BPR loss (train)")
    ln2 = ax2.plot(bpr["epoch"], bpr["val_ndcg10_sampled"], marker="s",
                   markersize=3, color="#F25C54",
                   label="NDCG@10 (val, sampled)")
    ax.set_xlabel("Epoch")
    ax.set_ylabel("BPR loss", color="#1E2761")
    ax2.set_ylabel("NDCG@10", color="#F25C54")
    ax.tick_params(axis="y", colors="#1E2761")
    ax2.tick_params(axis="y", colors="#F25C54")
    ax.set_title("(b) BPR variant", fontsize=10, loc="left", fontweight="bold")
    ax.set_xticks(bpr["epoch"].astype(int))
    ax2.grid(False)

    lns = ln1 + ln2
    ax.legend(lns, [l.get_label() for l in lns], loc="upper right",
              frameon=False, fontsize=8)

    fig.tight_layout()
    Path(args.out_pdf).parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(args.out_pdf, bbox_inches="tight")
    fig.savefig(args.out_png, bbox_inches="tight", dpi=200)
    print(f"[plot] Wrote {args.out_pdf}")
    print(f"[plot] Wrote {args.out_png}")


if __name__ == "__main__":
    main()
