"""
Compute simple baseline numbers for the comparison tables in the report.

Baselines:
  - Global-mean: predict the global average rating for every (u,i)
  - User-mean:   predict each user's own average training rating
  - Popularity:  for top-N, recommend the most-rated items globally

Usage:
    python scripts/baselines.py --data data/processed.pkl --k 10 --out results/baseline_metrics.json
"""
import argparse
import json
import pickle
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np


def mae(a, b): return float(np.mean(np.abs(a - b)))
def rmse(a, b): return float(np.sqrt(np.mean((a - b) ** 2)))


def precision_recall_ndcg(recommended, relevant, k):
    topk = recommended[:k]
    hits = sum(1 for i in topk if i in relevant)
    p = hits / k if k else 0.0
    r = hits / len(relevant) if relevant else 0.0
    dcg = 0.0
    for i, item in enumerate(topk):
        if item in relevant:
            dcg += 1.0 / np.log2(i + 2)
    ideal_hits = min(k, len(relevant))
    idcg = sum(1.0 / np.log2(i + 2) for i in range(ideal_hits))
    n = dcg / idcg if idcg > 0 else 0.0
    return p, r, n


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="data/processed.pkl")
    ap.add_argument("--k", type=int, default=10)
    ap.add_argument("--out", default="results/baseline_metrics.json")
    args = ap.parse_args()

    with open(args.data, "rb") as f:
        data = pickle.load(f)
    train, test = data["train"], data["test"]
    n_movies = data["n_movies"]

    # -------- Rating-prediction baselines --------
    train_ratings = train[:, 2].astype(np.float32)
    global_mean = float(train_ratings.mean())

    user_mean = defaultdict(list)
    for u, _, r, _ in train:
        user_mean[int(u)].append(float(r))
    user_mean = {u: np.mean(rs) for u, rs in user_mean.items()}

    test_ratings = test[:, 2].astype(np.float32)
    pred_gm = np.full_like(test_ratings, global_mean)
    pred_um = np.array([user_mean.get(int(u), global_mean) for u, *_ in test],
                       dtype=np.float32)

    # -------- Popularity baseline for top-N --------
    pop = Counter()
    for _, m, _, _ in train:
        pop[int(m)] += 1
    pop_ranked = [m for m, _ in pop.most_common()]  # all items sorted by popularity

    train_by_user = defaultdict(set)
    for u, i, _, _ in train:
        train_by_user[int(u)].add(int(i))

    test_by_user = defaultdict(set)
    for u, i, _, _ in test:
        test_by_user[int(u)].add(int(i))

    precs, recs, ndcgs = [], [], []
    for uid in test_by_user:
        seen = train_by_user[uid]
        rec_list = [m for m in pop_ranked if m not in seen][:args.k]
        p, r, n = precision_recall_ndcg(rec_list, test_by_user[uid], args.k)
        precs.append(p); recs.append(r); ndcgs.append(n)

    P = float(np.mean(precs))
    R = float(np.mean(recs))
    F = 2 * P * R / (P + R) if (P + R) > 0 else 0.0
    N = float(np.mean(ndcgs))

    out = {
        "global_mean": {"MAE": mae(test_ratings, pred_gm), "RMSE": rmse(test_ratings, pred_gm)},
        "user_mean":   {"MAE": mae(test_ratings, pred_um), "RMSE": rmse(test_ratings, pred_um)},
        "popularity":  {
            "Precision@10": P, "Recall@10": R,
            "F1@10": F, "NDCG@10": N,
        },
    }
    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    with open(args.out, "w") as f:
        json.dump(out, f, indent=2)

    print(f"[baselines] Saved {args.out}")
    print(json.dumps(out, indent=2))


if __name__ == "__main__":
    main()
