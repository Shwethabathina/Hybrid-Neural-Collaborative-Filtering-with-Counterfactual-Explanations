"""
Fill numeric placeholders in report/report.tex from results JSONs.

Usage (after training + evaluation):
    python scripts/fill_report.py

This script auto-detects and fills tokens for:
  - MSE model: [MAE] [RMSE] [P10-MSE] [R10-MSE] [F10-MSE] [NDCG10-MSE]
  - BPR model: [P10-BPR] [R10-BPR] [F10-BPR] [NDCG10-BPR]
  - Baselines: [GM-MAE] [GM-RMSE] [UM-MAE] [UM-RMSE] [POP-P] [POP-R] [POP-F] [POP-N]
  - Misc:      [NUM-EPOCHS]
"""
import argparse
import json
from pathlib import Path


def load_json(path: Path) -> dict:
    with open(path) as f:
        return json.load(f)


def build_replacements(args):
    def fmt(x, n=4):
        try:
            return f"{float(x):.{n}f}"
        except Exception:
            return "--"

    reps = {}

    if args.metrics_mse and Path(args.metrics_mse).exists():
        m = load_json(Path(args.metrics_mse))
        reps.update({
            "[MAE]":        fmt(m.get("MAE")),
            "[RMSE]":       fmt(m.get("RMSE")),
            "[P10-MSE]":    fmt(m.get("Precision@10")),
            "[R10-MSE]":    fmt(m.get("Recall@10")),
            "[F10-MSE]":    fmt(m.get("F1@10")),
            "[NDCG10-MSE]": fmt(m.get("NDCG@10")),
            "[P10]":        fmt(m.get("Precision@10")),
            "[R10]":        fmt(m.get("Recall@10")),
            "[F10]":        fmt(m.get("F1@10")),
            "[NDCG10]":     fmt(m.get("NDCG@10")),
        })

    if args.metrics_bpr and Path(args.metrics_bpr).exists():
        m = load_json(Path(args.metrics_bpr))
        reps.update({
            "[P10-BPR]":    fmt(m.get("Precision@10")),
            "[R10-BPR]":    fmt(m.get("Recall@10")),
            "[F10-BPR]":    fmt(m.get("F1@10")),
            "[NDCG10-BPR]": fmt(m.get("NDCG@10")),
        })

    if args.metrics_baselines and Path(args.metrics_baselines).exists():
        b = load_json(Path(args.metrics_baselines))
        gm = b.get("global_mean", {})
        um = b.get("user_mean", {})
        pop = b.get("popularity", {})
        reps.update({
            "[GM-MAE]":  fmt(gm.get("MAE")),
            "[GM-RMSE]": fmt(gm.get("RMSE")),
            "[UM-MAE]":  fmt(um.get("MAE")),
            "[UM-RMSE]": fmt(um.get("RMSE")),
            "[POP-P]":   fmt(pop.get("Precision@10")),
            "[POP-R]":   fmt(pop.get("Recall@10")),
            "[POP-F]":   fmt(pop.get("F1@10")),
            "[POP-N]":   fmt(pop.get("NDCG@10")),
        })

    if args.curve_csv and Path(args.curve_csv).exists():
        import pandas as pd
        df = pd.read_csv(args.curve_csv)
        reps["[NUM-EPOCHS]"] = str(len(df))

    return reps


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--template",          default="report/report.tex")
    ap.add_argument("--metrics_mse",       default="results/eval_metrics.json")
    ap.add_argument("--metrics_bpr",       default="results/eval_metrics_bpr.json")
    ap.add_argument("--metrics_baselines", default="results/baseline_metrics.json")
    ap.add_argument("--curve_csv",         default="results/training_curve.csv")
    ap.add_argument("--out",               default="report/report_filled.tex")
    ap.add_argument("--metrics", default=None, help="Legacy alias for --metrics_mse")
    args = ap.parse_args()
    if args.metrics and not Path(args.metrics_mse).exists():
        args.metrics_mse = args.metrics

    reps = build_replacements(args)

    text = Path(args.template).read_text()
    for token, val in reps.items():
        text = text.replace(token, val)

    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    Path(args.out).write_text(text)

    print(f"[fill] Wrote {args.out}")
    print(f"[fill] Replacements applied ({len(reps)} tokens):")
    for k, v in sorted(reps.items()):
        print(f"  {k:18s} -> {v}")


if __name__ == "__main__":
    main()
