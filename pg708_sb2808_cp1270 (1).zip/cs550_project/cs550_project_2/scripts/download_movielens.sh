#!/usr/bin/env bash
# Download MovieLens 1M and extract into ./ml-1m/
# Usage: bash scripts/download_movielens.sh
set -euo pipefail

URL="https://files.grouplens.org/datasets/movielens/ml-1m.zip"
ZIP="ml-1m.zip"

if [ -d "ml-1m" ]; then
  echo "[data] ./ml-1m already exists -- skipping download."
  exit 0
fi

echo "[data] Downloading MovieLens 1M ($URL)"
if command -v wget >/dev/null 2>&1; then
  wget -q --show-progress "$URL" -O "$ZIP"
elif command -v curl >/dev/null 2>&1; then
  curl -L --progress-bar -o "$ZIP" "$URL"
else
  echo "Need wget or curl." >&2
  exit 1
fi

echo "[data] Extracting..."
unzip -q "$ZIP"
rm "$ZIP"
echo "[data] Done. Files in ./ml-1m/:"
ls -la ml-1m/
