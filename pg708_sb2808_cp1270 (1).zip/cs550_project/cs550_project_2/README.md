# CS 550 Project — Hybrid NCF with Counterfactual Explanations

**Team:** Prithvi Govindareddy (pg708), Shweatha Bathina Mallikarjuna (sb2808), Chiranjeevi Bhuvaneshwari Pamarthy (cp1270)

An explainable deep-learning recommender system trained on **MovieLens 1M**, combining Hybrid Neural Collaborative Filtering (GMF + MLP + genre content tower) with counterfactual explanations.

## Headline results

| Task | Our model | Best baseline | Improvement |
|---|---|---|---|
| MAE (rating) | **0.6835** | user-mean: 0.8273 | **17.4%** |
| RMSE (rating) | **0.8661** | user-mean: 1.0341 | **16.2%** |
| NDCG@10 (ranking) | **0.2898** | popularity: 0.2002 | **44.8%** |

The MSE variant wins on rating prediction; the BPR variant wins on top-N ranking. Same architecture — only the loss function differs.

## How to run (fresh install, ~5 minutes)

```bash
# 1. Create environment
conda create -n cs550 python=3.11 -y
conda activate cs550

# 2. Install dependencies (numpy<2 and torch<2.5 pinned for compatibility)
pip install -r requirements.txt

# 3. Verify codebase works (synthetic smoke tests, ~1 min total)
python notebooks/smoke_test.py       # expects: SMOKE TEST PASSED.
python notebooks/smoke_test_bpr.py   # expects: BPR SMOKE TEST PASSED.
```

If both smoke tests pass, the codebase is fully functional.

## Reproduce the numbers in the report

Trained checkpoints + processed data are in the zip.

```bash
# Rating-prediction metrics (Table 1 in the report)
python -m evaluation.evaluate \
    --data data/processed.pkl \
    --ckpt checkpoints/hybrid_ncf.pt --k 10

# Top-10 ranking metrics (Table 2 in the report)
python -m evaluation.evaluate \
    --data data/processed.pkl \
    --ckpt checkpoints/hybrid_ncf_bpr.pt --k 10

# Baselines (global-mean, user-mean, popularity)
python scripts/baselines.py --data data/processed.pkl --k 10
```

Expected numbers match `results/eval_metrics.json`, `results/eval_metrics_bpr.json`, and `results/baseline_metrics.json`.

## Launch the interactive demo

```bash
streamlit run demo/app.py -- \
    --data data/processed.pkl \
    --ckpt checkpoints/hybrid_ncf.pt \
    --metrics_json results/eval_metrics.json
```

Browser opens at `http://localhost:8501`. Four tabs: **Recommendations**, **Why this?** (counterfactual explanations), **Your profile**, **Model evaluation**.

The qualitative example in the report (user 2083 → Schindler's List) is reproducible by selecting user 2083 in the sidebar and clicking "Why this?".

## Retrain from scratch (optional, GPU recommended)

```bash
bash scripts/download_movielens.sh
python data/preprocess.py --data_dir ./ml-1m --out_dir ./data

# Train MSE variant (~3 min on GPU, ~30 min on CPU)
python train.py --data data/processed.pkl --epochs 25 \
    --ckpt checkpoints/hybrid_ncf.pt

# Train BPR variant (~2 min on GPU)
python train_bpr.py --data data/processed.pkl --epochs 20 \
    --ckpt checkpoints/hybrid_ncf_bpr.pt
```

Preprocessing is deterministic (seed=42), so a re-run reproduces the same split the checkpoints were trained on.

## Run on Amarel as a SLURM job

```bash
mkdir -p slurm/logs
sbatch slurm/run_all.sbatch
```

Runs data download + preprocess + train + evaluate in ~15–25 minutes.

## Troubleshooting

**`RuntimeError: Numpy is not available`** when running any Python script.
Your NumPy is newer than the pinned PyTorch supports. Fix:
```bash
pip install "numpy<2" --force-reinstall
```

**`ModuleNotFoundError: No module named 'numpy._core.numeric'`** when loading `data/processed.pkl`.
The pickle was created with a different NumPy major version. Regenerate from raw:
```bash
bash scripts/download_movielens.sh
python data/preprocess.py --data_dir ./ml-1m --out_dir ./data
```
The split is deterministic, so the regenerated split matches the trained checkpoints.

**SLURM `module load anaconda` fails on Amarel.**
Amarel's module system doesn't use that name. Skip the `module load` step and use `source ~/.bashrc && conda activate cs550` instead (see `slurm/run_all.sbatch`).

## What's in this zip

| Path | Contents |
|---|---|
| `report/report.pdf` | Compiled 5-page project report (main deliverable) |
| `report/report_filled.tex` | LaTeX source with all numbers filled |
| `report/figures/training_curves.pdf` | Training-dynamics figure |
| `slides/presentation.pptx` | 9-slide presentation deck |
| `train.py`, `train_bpr.py` | MSE and BPR training loops |
| `models/hybrid_ncf.py` | Hybrid-NCF architecture |
| `evaluation/evaluate.py` | All 6 metrics (MAE, RMSE, P@K, R@K, F1@K, NDCG@K) |
| `explain/counterfactual.py` | Counterfactual explainer (trustworthiness bonus) |
| `explain/recommend.py` | Top-K inference helper |
| `demo/app.py` | Streamlit demo |
| `data/preprocess.py` | Raw .dat → processed.pkl pipeline |
| `data/processed.pkl` | Train/test split (6040 users, 3706 movies, seed=42) |
| `checkpoints/hybrid_ncf.pt` | MSE-trained model |
| `checkpoints/hybrid_ncf_bpr.pt` | BPR-trained model |
| `results/*.json` | All metrics on test set |
| `scripts/baselines.py` | Global-mean, user-mean, popularity baselines |
| `scripts/qualitative_example.py` | Prints explainer output for the report's example |
| `scripts/plot_training_curves.py` | Generates the training-dynamics figure |
| `notebooks/smoke_test*.py` | Synthetic end-to-end tests |
| `slurm/run_all.sbatch` | Amarel SLURM batch script |
| `requirements.txt` | Python dependencies (NumPy 1.x pinned) |

## The approach, in one paragraph

Hybrid Neural Collaborative Filtering combines three signal paths in a single model: a **Generalized Matrix Factorization (GMF) branch** (element-wise product of user and item embeddings, capturing linear collaborative signal), a **Multi-Layer Perceptron (MLP) branch** (concatenated embeddings through non-linear layers, capturing non-linear interactions), and a **genre content tower** (multi-hot genre encoding through a small MLP, adding content-based signal for sparse items). The three outputs are fused through a final head. We train two variants with the same architecture: MSE regression (for rating prediction) and Bayesian Personalized Ranking (BPR) (for top-N ranking). For the trustworthiness bonus, a **counterfactual explanation module** perturbs the learned user embedding by subtracting the contribution of individual history items, quantifying which past ratings most drove a given recommendation and surfacing the alternative recommendations the user would see if those items were removed. Genre-level gradient attribution provides a complementary content-side explanation.

## References

Key papers cited in the report:
- He et al., "Neural Collaborative Filtering" (WWW 2017)
- Rendle et al., "BPR: Bayesian Personalized Ranking from Implicit Feedback" (UAI 2009)
- Tan et al., "Counterfactual Explainable Recommendation" (CIKM 2021, arXiv:2108.10539)
- Cañamares & Castells, "Should I Follow the Crowd? A Probabilistic Analysis of the Effectiveness of Popularity in Recommender Systems" (SIGIR 2018)
